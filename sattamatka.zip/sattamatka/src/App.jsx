import React from 'react'
import Hero from './components/Hero'
import Navbar from './components/Navbar'
import AllSection from './components/AllSection'
import Records from './components/Records'
import Test from './components/Test'
import Footer from './components/footer'


const App = () => {
  return (
    <div>
      <Navbar/>
       <Hero/>
       <AllSection/>
       <Records/>
       <Test/>
       <Footer/>
       
    </div>
  )
}

export default App

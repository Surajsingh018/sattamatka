import React from 'react'
const Records = () => {
  return (
    <div>
       {/* Satta Chart */}
      <div className="w-full text-white text-center text-xl font-extrabold py-4 bg-gradient-to-b from-pink-600 to-orange-400 mt-1">
        SATTA CHART
      </div>
      <div className="  w-full">
        <div className="flex flex-row flex-wrap border border-[#660033]">
          <div className="w-1/2 bg-gradient-to-b from-white to-[#FFF0F4] border border-[#FF3366] flex flex-col p-2 sm:p-3">
            <div className="text-sm sm:text-base md:text-lg font-extrabold text-purple-700 text-center uppercase tracking-wide">
              DESWAR
            </div>
            <div className="text-red-500 text-xs sm:text-sm font-semibold text-center mb-1 tracking-wide">
              (""05:15 AM")
            </div>
            <div className="flex flex-row justify-center items-center gap-2 flex-wrap text-sm sm:text-base md:text-lg font-bold text-center mb-2">
              <span className="text-gray-700">{18}</span>
              <span className="text-green-600 flex items-center gap-1 font-extrabold">
                ➡️
                <span className="text-blue-700">["96"]</span>
              </span>
            </div>
            <div className="text-center mt-auto">
              <a
                className="border border-[#FF7A30] text-[#FF7A30] hover:bg-[#FF7A30] hover:text-white text-xs sm:text-sm md:text-base font-bold py-2 px-4 mt-2 rounded-md transition duration-200 inline-block"
                href=""
              >
                Record Chart
              </a>
            </div>
          </div>
          <div className="w-1/2 bg-gradient-to-b from-white to-[#FFF0F4] border border-[#FF3366] flex flex-col p-2 sm:p-3">
            <div className="text-sm sm:text-base md:text-lg font-extrabold text-purple-700 text-center uppercase tracking-wide">
              NCR
            </div>
            <div className="text-red-500 text-xs sm:text-sm font-semibold text-center mb-1 tracking-wide">
              ( 02:15 PM )
            </div>
            <div className="flex flex-row justify-center items-center gap-2 flex-wrap text-sm sm:text-base md:text-lg font-bold text-center mb-2">
              <span class="text-gray-700">{"07"}</span>
              <span className="text-green-600 flex items-center gap-1 font-extrabold">
                ➡️<span className="text-blue-700">[ 54 ]</span>
              </span>
            </div>
            <div className="text-center mt-auto">
              <a
                className="border border-[#FF7A30] text-[#FF7A30] hover:bg-[#FF7A30] hover:text-white text-xs sm:text-sm md:text-base font-bold py-2 px-4 mt-2 rounded-md transition duration-200 inline-block"
                href="/satta-results/ncr"
                data-discover="true"
              >
                Record Chart
              </a>
            </div>
          </div>
          <div className="w-1/2 bg-gradient-to-b from-white to-[#FFF0F4] border border-[#FF3366] flex flex-col p-2 sm:p-3">
            <div className="text-sm sm:text-base md:text-lg font-extrabold text-purple-700 text-center uppercase tracking-wide">
              TAJ
            </div>
            <div className="text-red-500 text-xs sm:text-sm font-semibold text-center mb-1 tracking-wide">
              (""03:00 PM")
            </div>
            <div className="flex flex-row justify-center items-center gap-2 flex-wrap text-sm sm:text-base md:text-lg font-bold text-center mb-2">
              <span className="text-gray-700">{}</span>
              <span className="text-green-600 flex items-center gap-1 font-extrabold">
                ➡️
                <span className="text-blue-700">["99"]</span>
              </span>
            </div>
            <div className="text-center mt-auto">
              <a
                className="border border-[#FF7A30] text-[#FF7A30] hover:bg-[#FF7A30] hover:text-white text-xs sm:text-sm md:text-base font-bold py-2 px-4 mt-2 rounded-md transition duration-200 inline-block"
                href=""
              >
                Record Chart
              </a>
            </div>
          </div>
          <div className="w-1/2 bg-gradient-to-b from-white to-[#FFF0F4] border border-[#FF3366] flex flex-col p-2 sm:p-3">
            <div className="text-sm sm:text-base md:text-lg font-extrabold text-purple-700 text-center uppercase tracking-wide">
              DELHI BAZAR
            </div>
            <div className="text-red-500 text-xs sm:text-sm font-semibold text-center mb-1 tracking-wide">
              ( 03:15 PM )
            </div>
            <div className="flex flex-row justify-center items-center gap-2 flex-wrap text-sm sm:text-base md:text-lg font-bold text-center mb-2">
              <span class="text-gray-700">{}</span>
              <span className="text-green-600 flex items-center gap-1 font-extrabold">
                ➡️<span className="text-blue-700">[ 58 ]</span>
              </span>
            </div>
            <div className="text-center mt-auto">
              <a
                className="border border-[#FF7A30] text-[#FF7A30] hover:bg-[#FF7A30] hover:text-white text-xs sm:text-sm md:text-base font-bold py-2 px-4 mt-2 rounded-md transition duration-200 inline-block"
                href="/satta-results/ncr"
                data-discover="true"
              >
                Record Chart
              </a>
            </div>
          </div>
          <div className="w-1/2 bg-gradient-to-b from-white to-[#FFF0F4] border border-[#FF3366] flex flex-col p-2 sm:p-3">
            <div className="text-sm sm:text-base md:text-lg font-extrabold text-purple-700 text-center uppercase tracking-wide">
              KASHIPUR
            </div>
            <div className="text-red-500 text-xs sm:text-sm font-semibold text-center mb-1 tracking-wide">
              (""04:15 AM")
            </div>
            <div className="flex flex-row justify-center items-center gap-2 flex-wrap text-sm sm:text-base md:text-lg font-bold text-center mb-2">
              <span className="text-gray-700">{}</span>
              <span className="text-green-600 flex items-center gap-1 font-extrabold">
                ➡️
                <span className="text-blue-700">[ ]</span>
              </span>
            </div>
            <div className="text-center mt-auto">
              <a
                className="border border-[#FF7A30] text-[#FF7A30] hover:bg-[#FF7A30] hover:text-white text-xs sm:text-sm md:text-base font-bold py-2 px-4 mt-2 rounded-md transition duration-200 inline-block"
                href=""
              >
                Record Chart
              </a>
            </div>
          </div>
          <div className="w-1/2 bg-gradient-to-b from-white to-[#FFF0F4] border border-[#FF3366] flex flex-col p-2 sm:p-3">
            <div className="text-sm sm:text-base md:text-lg font-extrabold text-purple-700 text-center uppercase tracking-wide">
              SHRI GANESH
            </div>
            <div className="text-red-500 text-xs sm:text-sm font-semibold text-center mb-1 tracking-wide">
              ( 04:40 PM )
            </div>
            <div className="flex flex-row justify-center items-center gap-2 flex-wrap text-sm sm:text-base md:text-lg font-bold text-center mb-2">
              <span class="text-gray-700">"{""}"</span>
              <span className="text-green-600 flex items-center gap-1 font-extrabold">
                ➡️<span className="text-blue-700">[ ]</span>
              </span>
            </div>
            <div className="text-center mt-auto">
              <a
                className="border border-[#FF7A30] text-[#FF7A30] hover:bg-[#FF7A30] hover:text-white text-xs sm:text-sm md:text-base font-bold py-2 px-4 mt-2 rounded-md transition duration-200 inline-block"
                href="/satta-results/ncr"
                data-discover="true"
              >
                Record Chart
              </a>
            </div>
          </div>{" "}
          <div className="w-1/2 bg-gradient-to-b from-white to-[#FFF0F4] border border-[#FF3366] flex flex-col p-2 sm:p-3">
            <div className="text-sm sm:text-base md:text-lg font-extrabold text-purple-700 text-center uppercase tracking-wide">
              FARIDABAD
            </div>
            <div className="text-red-500 text-xs sm:text-sm font-semibold text-center mb-1 tracking-wide">
              (""06:00 PM")
            </div>
            <div className="flex flex-row justify-center items-center gap-2 flex-wrap text-sm sm:text-base md:text-lg font-bold text-center mb-2">
              <span className="text-gray-700">"{"21"}"</span>
              <span className="text-green-600 flex items-center gap-1 font-extrabold">
                ➡️
                <span className="text-blue-700">[ ]</span>
              </span>
            </div>
            <div className="text-center mt-auto">
              <a
                className="border border-[#FF7A30] text-[#FF7A30] hover:bg-[#FF7A30] hover:text-white text-xs sm:text-sm md:text-base font-bold py-2 px-4 mt-2 rounded-md transition duration-200 inline-block"
                href=""
              >
                Record Chart
              </a>
            </div>
          </div>
          <div className="w-1/2 bg-gradient-to-b from-white to-[#FFF0F4] border border-[#FF3366] flex flex-col p-2 sm:p-3">
            <div className="text-sm sm:text-base md:text-lg font-extrabold text-purple-700 text-center uppercase tracking-wide">
              GHAZIABAD
            </div>
            <div className="text-red-500 text-xs sm:text-sm font-semibold text-center mb-1 tracking-wide">
              ( 09:40 PM )
            </div>
            <div className="flex flex-row justify-center items-center gap-2 flex-wrap text-sm sm:text-base md:text-lg font-bold text-center mb-2">
              <span class="text-gray-700">{}</span>
              <span className="text-green-600 flex items-center gap-1 font-extrabold">
                ➡️<span className="text-blue-700">[ ]</span>
              </span>
            </div>
            <div className="text-center mt-auto">
              <a
                className="border border-[#FF7A30] text-[#FF7A30] hover:bg-[#FF7A30] hover:text-white text-xs sm:text-sm md:text-base font-bold py-2 px-4 mt-2 rounded-md transition duration-200 inline-block"
                href="/satta-results/ncr"
                data-discover="true"
              >
                Record Chart
              </a>
            </div>
          </div>
          <div className="w-1/2 bg-gradient-to-b from-white to-[#FFF0F4] border border-[#FF3366] flex flex-col p-2 sm:p-3">
            <div className="text-sm sm:text-base md:text-lg font-extrabold text-purple-700 text-center uppercase tracking-wide">
              GALI
            </div>
            <div className="text-red-500 text-xs sm:text-sm font-semibold text-center mb-1 tracking-wide">
              (""11:40 PM")
            </div>
            <div className="flex flex-row justify-center items-center gap-2 flex-wrap text-sm sm:text-base md:text-lg font-bold text-center mb-2">
              <span className="text-gray-700">" "</span>
              <span className="text-green-600 flex items-center gap-1 font-extrabold">
                ➡️
                <span className="text-blue-700">[ ]</span>
              </span>
            </div>
            <div className="text-center mt-auto">
              <a
                className="border border-[#FF7A30] text-[#FF7A30] hover:bg-[#FF7A30] hover:text-white text-xs sm:text-sm md:text-base font-bold py-2 px-4 mt-2 rounded-md transition duration-200 inline-block"
                href=""
              >
                Record Chart
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* SATTA MATKA RECORD CHART  */}
      <div className="w-full bg-[#FFE0EC] py-4 px-2 sm:px-4 md:px-6">
        <div className="flex flex-wrap justify-center items-center gap-2 mb-6 bg-green-300 py-3 px-2 rounded-md shadow-md">
          <h1 className="text-red-400 font-extrabold text-xl md-1">
            SATTA MATKA RECORD CHART
            <span className="text-sm md:text-base lg:text-xl font-semibold text-yellow-200 gap-20px">
              JULY 2025
            </span>
          </h1>
        </div>
      </div>
    
    </div>
  )
}

export default Records

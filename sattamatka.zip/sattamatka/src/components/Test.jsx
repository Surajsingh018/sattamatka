import React from 'react'
import golden from "../assets/golden-pot.png?url";


const Test = () => {
  return (
    <section className="bg-white w-full pt-10 pb-12 border-t-8 border-[#116353] border-b-8 border-red-600">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-12 items-center px-4">
        <div
          className="flex-1 text-gray-800 text-lg leading-relaxed"
          style={{ fontFamily: 'math' }}
        >
          <p>
            <span className="font-bold uppercase">Welcome to DAILY SATTA RESULT</span>, your ultimate destination for all things related to daily satta result and Satta matka results. We are dedicated to providing precise and up-to-date details about the world of Satta matka. We aim to be your primary resource for the latest information in this exciting and ever-evolving industry, helping experienced players and newcomers alike. Our team of dedicated experts brings together years of experience in the daily satta matka and daily satta king industry to ensure you receive the most reliable updates and results. We understand the diverse nature of the game and the importance of reliable information to guide informed decisions. Our dedication lies in producing trustworthy and impartial content while upholding principles of honesty and transparency. What sets us apart is our unwavering focus on serving our audience diligently. We recognize the varying requirements of daily satta matka and satta king news enthusiasts, tailoring our content for newcomers and seasoned players.
          </p>
        </div>
        <div className="flex-1 flex justify-center">
          <img
            src={golden}
            alt="Golden Pot"
            className="rounded-none object-cover w-[430px] h-[430px] max-w-full"
          />
        </div>
      </div>
    </section>
  )
}

export default Test

import React from "react";
import money1 from "../assets/money1.png?url";
import whatsapp from "../assets/whatsapp1.png?url";
import telegram from "../assets/telegram1.png?url";
import money2 from "../assets/money2.png?url";

const AllSection = () => {
  return (
    <div className="w-full flex flex-col items-center justify-center bg-yellow-200">
      {/* Money Image */}
      <div className="relative mx-auto mt-20">
        <img
          src={money1}
          className="w-[450px] h-[400px] object-cover shadow-md rounded"
          alt="Money"
        />
      </div>

      {/* Join WhatsApp Group Button */}
      <a
        href="https://chat.whatsapp.com/KrrDKOC3H91EKgDochF5L4?mode=ac_t"
        target="_blank"
        rel="noopener noreferrer"
        className="bg-green-700 hover:bg-green-800 text-white font-bold py-2 px-8 rounded-full mt-3 transition shadow-md"
      >
        JOIN WHATSAPP GROUP
      </a>

      {/* Cards Section */}
      <div className="w-full bg-yellow-200 pt-6">
        {[1, 2].map((item) => (
          <div
            key={item}
            className="max-w-[1200px] mx-auto mb-6 border-4 border-blue-600 rounded-lg p-4 bg-white text-center"
          >
            <p className="text-xs md:text-sm font-semibold text-black mb-2">
              FARIDABAD | GAZIYABAD | GALI | DS
            </p>
            <p className="text-red-600 text-sm font-bold">
              🔥 DIRECT COMPANY SE LEAK JODI 🔥
            </p>

            <p className="text-xs md:text-sm font-semibold text-black mt-2 mb-4 px-2 leading-snug">
              JO BHAI APNA LOSS COVER KARNA CHAHHTE HO ,GAME SINGAL JODI MAI HI
              MILEGA ,GAME KISI KA BAAP NAHI KAAT SAKTA. APNI BOOKING KARANE K
              LIVE ABHI WHATSAPP YA CALL KARE !
            </p>

            <div className="text-red-600 text-xl font-bold mb-1">
              SATTA KING
            </div>
            <div className="text-green-600 text-xl font-bold mb-3">ADD</div>

            <button className="bg-red-600 hover:bg-red-700 transition text-white text-sm font-bold rounded-full px-5 py-1">
              DELHI SATTA BAZAR
            </button>
          </div>
        ))}
      </div>

      {/* Full Width Black Gradient Section */}
      <div className="w-full bg-gradient-to-b from-black to-[#063b3d] text-white text-center py-12 px-4">
        <div className="max-w-screen-xl mx-auto px-4">
          <div className="text-yellow-300 text-3xl font-extrabold mb-2">
            🔥 FEES GAME PASS KE BAD 🔥
          </div>
          <div className="text-white text-2xl font-semibold mb-2">
            🎯 FARIDABAD GAZIYABAD GALI DS 🎯
          </div>
          <div className="text-red-400 underline font-bold mb-1">
            💯 LEAK SINGLE JODI GAME 💯
          </div>
          <div className="text-white text-2xl font-semibold mb-2">
            MUMBAI HEAD BRANCH
          </div>
          <div className="text-yellow-300 text-3xl font-extrabold mb-2">
            👑 SATTA KING 👑
          </div>
          <div className="text-white text-2xl font-bold mb-4">ADD</div>
          <button className="bg-red-600 hover:bg-red-700 transition text-white text-2xl font-bold rounded-full px-12 py-3 mt-2">
            SATTA KING
          </button>
        </div>
      </div>
      {/* Full width Blue Gradient Section  */}
      <div className="w-full bg-[#1877e5] py-7 px-4 text-center">
        <div className="text-white text-4xl font-extrabold mb-2 ">
          daily sattaresults.com
        </div>
        <div className="text-white text-lg font-medium mb-2 ">
          SATTA KING | SATTA RESULT | SATTA RECORD
        </div>
      </div>

      {/* Second card and image section  */}
      <div className="w-full bg-yellow-200 pt-6">
        <div>
          <img
            src={money2}
            className=" max-w-full h-[110px] // Small screens: smaller height sm:h-[250px] // Tablet: medium height md:h-[250px]   // Desktop: original height object-cover mx-auto rounded "
          />
        </div>
        {/* Section 1 - Red and Blue boxes */}
        <div className="max-w-[1200px] mx-auto mb-3 border-4 border-blue-600 rounded-lg p-4 bg-white text-center mt-2">
          <p className="text-black font-bold">
            🙏🏻{" "}
            <a className="text-blue-700 underline" href="#">
              AFTER PASS
            </a>{" "}
            🙏🏻
            <br />
            FARIDABAD, GAZIYABAD GALI DISAWAR KI LEAK SINGLE JODI 100% PASS LEAK
            GAME LENE KE LIYE...
          </p>
          <h2 className="text-red-600 text-2xl font-bold my-2">SATTA KING</h2>
          <div className="text-green-600 text-xl font-bold mb-3">ADD</div>
          <button className="bg-red-600 text-white px-4 py-2 rounded-full font-bold">
            GAZIYABAD LEAK
          </button>
        </div>

        {/* Section 2 */}
        <div className="max-w-[1200px] mx-auto  border-4 border-blue-600 rounded-lg p-4 bg-white text-center mt-2 md-0">
          <p className="text-black font-bold">🙏🏻 HEAD BRANCH 🙏🏻</p>
          <p className="text-black font-bold">
            JO BHAI SATTA JEETNA AUR KAMANA CHAHTA HAI HUMARE SATH AAJ HI JUDE
            KYUKI GAME HUM PAAS KARATE HAI OR GAME LAGANA KA DAAM HO THO HE MSG
            YA CALL KARE🙏🏻
          </p>

          <p className="text-black  font-semibold">❇ SINGLE JODI BLAST ❇</p>
          <p className="text-red-600">✅ No Advance No Advance ✅</p>
          <h2 className="text-blue-600 text-2xl font-bold mt-2">
            TAJ SATTA KING
          </h2>
          <div className="text-green-600 text-xl font-bold mb-3">ADD</div>
          <button className="bg-green-600 text-white px-4 py-2 rounded-full font-bold">
            GALI LEAK
          </button>
        </div>
      </div>
      <div className="w-full text-white py-10 px-4 bg-gradient-to-b from-black to-blue-800 mt-1">
        <div className="text-center">
          <h3 className="text-yellow-400 font-bold text-xl mb-2">
            👑 मुखिया जी ऑनलाइन 👑
          </h3>
          <p className="text-yellow-300">सबसे ईमानदार खाईवाला</p>
          <hr className="my-2 border-t border-gray-500 w-1/3 mx-auto" />
          <p className="mb-2">🔥 RATE रेट 🔥</p>
          <p>👉 जोड़ी रेट : 10k 1050</p>
          <p>👉 हट्रफ रेट : 100k 1050</p>

          <h4 className="text-yellow-400 mt-4">👑 TIME TABLE 👇</h4>
          <div className="text-sm leading-relaxed">
            <hr />
            NCR .................... 1:45 PM
            <br />
            DELHI BAZAR ............ 2:45 PM
            <br />
            SHRI GANESH ............ 4:15 PM
            <br />
            FARIDABAD .............. 5:50 PM
            <br />
            GHAZIABAD .............. 9:15 PM
            <br />
            GALI ................... 11:15 PM
            <br />
            DISAWER ................ 4:00 AM
          </div>

          <p className="mt-4">ऑनली व्हाट्सएप मैसेज</p>
          <div className="bg-white text-black font-extrabold rounded px-4 py-2 inline-block mt-2">
            WHATSAPP NUMBER
            <br />
            9557297996
          </div>
          <br />
          <button className="bg-green-500 text-white px-6 py-2 rounded-full mt-3">
            WHATSAPP
          </button>
        </div>
      </div>


      {/* Floating Side Buttons */}
      <div className="fixed top-[35%] left-2 z-50 flex flex-col gap-3">
        {/* Blue Box */}
        <div className="bg-[#4699b6] text-white text-[15px] font-semibold rounded-xl px-2 py-1 text-center leading-snug shadow-md border border-white mb-2">
          मुखिया जी <br />
          ऑनलाइन सबसे <br />
          ईमानदार खाइवाल <br />
          जोड़ी रेट <br />
          10 k 1050 <br />
          हरूप रेट <br />
          100 k 1050
        </div>

        {/* Red Box */}
        <div className="bg-red-600 text-white text-xs font-semibold rounded-xl px-2 py-1 text-center leading-snug shadow-md border border-white mt-2">
          Play Online
          <br />
          Satta 100%
          <br />
          Trusted Satta
          <br />
          App Fast
          <br />
          Withdrawal
          <br />
          App
          <br />
          Download
          <br />
          Now
        </div>
      </div>

      {/* Floating Social Icons */}
      <div className="fixed z-50 flex flex-col gap-3 right-4 bottom-4">
        <a href="https://dailysattaresults.com/" target="_blank">
          <img
            src={telegram}
            className="w-12 h-12 md:w-16 md:h-16 cursor-pointer drop-shadow-xl rounded-full"
            alt="Telegram"
          />
        </a>
        <a
          href="https://chat.whatsapp.com/KrrDKOC3H91EKgDochF5L4?mode=ac_t"
          target="_blank"
        >
          <img
            src={whatsapp}
            className="w-12 h-12 md:w-16 md:h-16 cursor-pointer drop-shadow-xl rounded-full"
            alt="WhatsApp"
          />
        </a>
      </div>
    </div>
  );
};

export default AllSection;

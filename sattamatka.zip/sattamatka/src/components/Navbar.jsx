import React from "react";
import { FaHome } from "react-icons/fa";

const Navbar = () => {
  return (
    <nav className="w-full shadow-md z-50">
      <ul className="flex text-white font-bold text-[24px] text-center leading-none">
        <li className="bg-red-600 w-[20%] py-5 flex items-center justify-center border-r border-white hover:opacity-90 cursor-pointer">
          <FaHome size={30} />
        </li>
        <li className="bg-blue-600 w-[20%] py-5 border-r border-white hover:opacity-90 cursor-pointer">
          SATTA KING 786
        </li>
        <li className="bg-blue-600 w-[20%] py-5 border-r border-white hover:opacity-90 cursor-pointer">
          SATTA CHART
        </li>
        <li className="bg-blue-600 w-[20%] py-5 border-r border-white hover:opacity-90 cursor-pointer">
          TAJ SATTA KING
        </li>
        <li className="bg-green-600 w-[20%] py-5 hover:opacity-90 cursor-pointer">
          SATTA LEAK
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;

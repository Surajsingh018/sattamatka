import React from 'react';

const Hero = () => {
  return (
    <section >
      <header className='border-b-2 border-red-700'></header>
      <div className='bg-yellow-300 border-b text-center text-red-700 font-bold text-sm py-1'>
        <marquee>
          **SATTA KING, SATTAKING, SATTA RESULT, GALI RESULT, GALI SATTA, SATTA BAZAR, GALI SATTA RESULT, SATTA KING 2023, SATTA KING RESULT, SATTA KING UP, SATTA GAME TODAY RESULT, SATTA RESULT CHART, SATTA KING LIVE, DESAWAR SATTA, FARIDABAD SATTA, FARIDABAD RESULT, BLACK SATTA KING**
        </marquee>
        </div>
    <div className="bg-gradient-to-b from-[#10151a] to-[#16322c]  text-center p-6">
      <div className="text-yellow-300 font-bold text-2xl mb-2 leading-tight">आज की लीक जोड़ी यहाँ मिलेगी</div>
      <div className="text-white text-gray-200 text-xl font-bold mb-2">✮FARIDABAD GAZIYABAD GALI DS✮</div>
      <h1 className="text-4xl font-extrabold text-yellow-300">SATTA KING LEAK</h1>
      <h2 className="text-2xl mb-2 font-bold text-yellow-300">MUMBAI HEAD BRANCH MANAGER (CEO)</h2>
      <p className=" text-xl font-bold mb-2 text-white">ADD</p>
      <button className=" bg-red-600 hover:bg-red-700 transition on text-white text-xl font-bold px-10 py-2 mb-3 rounded-full">
        SATTA KING
      </button>
      </div>
      <div className='bg-yellow-400 py-2 text-center'>
        <div className='text-3xl font-bold text-black font-size-15px'>
        DELHI SATTA KING
        </div>
      </div>
    </section>
  );
};

export default Hero;

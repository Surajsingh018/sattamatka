import React from 'react'

const Footer = () => {
  return (
    <section className='w-full bg-black text-white py-6 py-4'>
        
            <div className='flex justify-center mb-4'>
                <span className='bg-gray-700 text-white rounded px-4 py-1'>Daily Satta Results
                    </span>
                    </div>
                    <div className='flex justify-center mb-6 gap-x-4'>
                        <button className='bg-red-600 hover:bg-red-700 text-white rounded px-4 py-1 '>ABOUT US</button>
                        <button className='bg-red-600 hover:bg-red-700 text-white rounded px-4 py-1 '>DISCLAIMER</button>
                        <button className='bg-red-600 hover:bg-red-700 text-white rounded px-4 py-1 '>PRIVACY POLICY</button>
                    </div>
                     <div className="flex flex-wrap justify-center gap-2 text-black font-semibold">
        {[
          'Satta King', 'Satta King darbar', 'Gali Result', 'Faridabad Satta Result', 'Gaziyabad Satta king',
          'Disawer Result', 'Satta King 2018', 'Satta King 2019', 'Satta King 2020', 'Satta King 2021',
          'Satta King 2022', 'Satta King 2023', 'Satta King 2024', 'Satta King 2025',
          'Satta King Record Chart', 'Satta Leak number', 'Satta King 786', 'Satta King leak',
          'UP game Satta', 'Satta Live Result', 'VIP Satta King', 'Satta Smart King', 'Satta king online',
          'Satta king blog', 'Delhi Satta king', 'Delhi Bazar', 'UP game king'
        ].map((item, index) => (
          <button key={index} className="bg-yellow-300 hover:bg-yellow-300 px-3 py-1 rounded">
            {item}
          </button>
        ))}
      </div>
        <div className="text-center text-sm text-white mt-6">
        Copyright © 2018-2028 Daily-Satta-Results
      </div>
    </section>
  )
}

export default Footer
